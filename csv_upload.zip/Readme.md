# Description
## Need to build a web app to upload and parse any CSV
Need to develop a small but somewhat complex PHP web app. The app must be based on PHP / JQUERY / HTML5 / MYSQL. Premise of the web app is pretty straight forward. Interface must be mobile ready.

Web app must be able to upload just about any size of CSV.... Data must be parsed directly into a database....certain fields are required.......file must be verified as CSV....make sure it conforms to certain standards (correct number of rows and columns) ....encoding must be accurate in case of french characters....and count number of rows to process because there will be size limitations. Once file is uploaded and parsed and validated.....it will then begin to query Google maps for coordinates...based on certain address fields in the CSV.... Once long/lat received app will query another dataset for additional information..... Program will then rebuild original CSV and add additional data received by query it added into columns. CSV will be saved and client will be notified of its completion.
# Contributor
- Yuyuan Z.